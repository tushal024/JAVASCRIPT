let h=3,b=4;

console.log("area of a triangle is: ",(h*b)/2);