let a=2,b=4;

a=a+b;//6
b=a-b//2
a=a-b//4

console.log("A is: ",a);
console.log("B is: ",b);