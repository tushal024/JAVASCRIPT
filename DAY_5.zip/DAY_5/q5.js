const pi=3.14;
let r=2;

console.log("volume of a sphere is: ",4/3*(pi*(r*r*r)));