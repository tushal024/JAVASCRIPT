const pi=3.14;
let r=5;

console.log("area of circle is: ",pi*r*r);