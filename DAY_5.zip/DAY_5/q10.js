let Base_Salary= 100;
let  HRA=10;
let  DA=5;
let  TA=8;


console.log("total is: ",Base_Salary+HRA+DA+TA);