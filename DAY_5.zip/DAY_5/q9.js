let c=24;

console.log("Celsius to Fahrenheit is: ",(9/5)*c+32);