let w=24,l=2;

console.log("area of a rectangle is: ",w*l);

