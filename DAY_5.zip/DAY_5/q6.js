let a=20,b=50,c=42;

console.log("the is average is:  ",(a+b+c)/3);