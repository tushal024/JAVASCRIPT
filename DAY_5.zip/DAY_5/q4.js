const pi=3.14;
let r=24;

console.log("Perimeter of the circle is: ",2*pi*r);