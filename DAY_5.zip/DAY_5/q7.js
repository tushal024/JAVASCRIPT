// Q. 7 Calculate the total salary of an employee. Given the basic salary and allowances, calculate the total salary.
// For example, if the basic salary is 2000 and the allowances are 500, the total salary would be 2500.



let basic_salary=98000,allowances=50000;

console.log("the total salary is: ",basic_salary+allowances);