let arr= [1, 2, 3, 4]

function doubleNumbers(a){

    let ans=a.map((ele)=>{
        return ele*2
    })
    console.log(ans);
    

}

doubleNumbers(arr)