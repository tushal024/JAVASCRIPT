let arr=[1,3,4,8]

function d_num(a){
    return a.forEach((el)=>{
    let n = el*el;
    console.log(n);
    
})
}
d_num(arr);







