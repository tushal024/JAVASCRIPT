let arr=[1,3,4,8]

function d_num(a){
    return a.map((el)=>{
            return el*2;
    })
}
console.log(d_num(arr));
