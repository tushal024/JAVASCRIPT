
function containsValue(a){
    let arr=[2,4,5,7,8]
    let b=arr.includes(a)
    return b;
}
console.log(containsValue(4));
