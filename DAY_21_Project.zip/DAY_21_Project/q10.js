let arr= [1, 2, 3, 4]

function printSquare(a){

    let ans=a.forEach((ele)=>{
        let seq=ele*ele;
        console.log(seq);
        
    })
}
printSquare(arr)