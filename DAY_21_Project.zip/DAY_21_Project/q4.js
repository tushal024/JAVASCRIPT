function findIndex(a){
    let arr=[1,2,3,4,5]
    return arr.indexOf(a)

}
console.log(findIndex(3));