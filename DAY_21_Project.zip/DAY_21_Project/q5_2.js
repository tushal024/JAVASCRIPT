
function  containsString(a){
    let arr=['SHAMBHU','SHIV','RUDRA','MAHESH']
    let b=arr.includes(a)
    return b;
}
console.log(containsString('SHIV'));
