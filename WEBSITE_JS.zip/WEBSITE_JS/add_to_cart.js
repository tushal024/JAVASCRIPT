fetch(`http://localhost:3000/single_product`)
.then((r)=>{
    return r.json();
})
.then((res)=>{
    console.log(res);
    document.getElementById("cartt").innerHTML=view(res)

    
})
.catch((er)=>{
    console.log(er);
    
})


function view(arr){
    return arr.map((el)=>{
        return ` <img src="${el.img}" alt="">
               <p class="mb-[10px]"> ${el.dis}</p>
        `
    })
}