/** @type {import('tailwindcss').Config} */
module.exports = {
    content: ["header.html"],
    theme: {
      extend: {},
    },
    plugins: [],
  }
  
  