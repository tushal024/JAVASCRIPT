setTimeout(()=>{
    document.getElementById("u1").style.display="block"
},3000)




document.getElementById("cl").addEventListener("click",()=>{
    // clearInterval()
     document.getElementById("u1").style.display="none"
})