let reverseString=(name)=>{

    let x= name.length-1; //5

    let ss = ""
    for(let y=x;y>=0;y--){

        // console.log(name[y])

        s = name[y]
        ss = ss+s
        
        
    }
    console.log(ss);
    
}

reverseString("tushal")
