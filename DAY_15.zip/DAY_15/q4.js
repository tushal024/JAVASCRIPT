function fac(num){

    cc=1
    for(a=1;a<=num;a++){
        cc *=a;
    }
    return cc;

}
console.log(fac(5))