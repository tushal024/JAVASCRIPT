

function prime(num){

    let sh=0
    for(let a=1;a<=50;a++){
        if(num%a==0){
            sh++;
        }
       

    }
    

}


prime(50)
