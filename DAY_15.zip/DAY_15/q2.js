function calculateArea(length,width){

    return area= length*width;
}

console.log(calculateArea(2,3));