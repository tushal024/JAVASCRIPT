let amount=80,tex=18,ser=5;
let total=amount+ser+(amount*tex)/100;
console.log("total amount is: ",total);