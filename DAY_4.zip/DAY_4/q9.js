let amount=125,inte=5,total_value=amount+(amount*inte)/100;

console.log("total amount is: ",total_value);


