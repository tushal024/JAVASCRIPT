let x=10,y=20,z=30,t=x+y+z;

console.log("sum of x,y and z is: ",t);
