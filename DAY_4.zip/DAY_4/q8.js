let a=20,b=5,c=a/b;

console.log("divide is : ",c);