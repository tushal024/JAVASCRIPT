// Question: Determine the total bill amount including 8% tax and a $20 service fee for 
// a purchase of $250 with a $30 discount.

// Input: $250
// Output: Total bill amount: $246.4

let prise 