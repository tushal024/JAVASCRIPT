var value= 2500, rate=4, time=5;


var s_i= (value*rate*time)/100;

console.log("Simple Interest is: ",s_i);