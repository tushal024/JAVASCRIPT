let amount=40,inte=15;

let total_amount=amount+(amount*inte)/100;

console.log("total amount is : ",total_amount);