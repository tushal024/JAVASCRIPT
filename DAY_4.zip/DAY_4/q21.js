let salary_per_hour=30;

let anual_salary=30*2000;

console.log("anual salary is: ",anual_salary);
