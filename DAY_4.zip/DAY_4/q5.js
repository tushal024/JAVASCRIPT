let x=8,y=4;
console.log("product of two number is: ",x*y);