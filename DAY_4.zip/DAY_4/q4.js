let salary_per_hour=15;

let weekly_salary=40*15;

console.log("Weekly salary is: ",weekly_salary);
