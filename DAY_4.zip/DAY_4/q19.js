let a=25,b=7;

console.log("reminder is: ",a%b);