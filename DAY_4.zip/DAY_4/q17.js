let a=3,b=4,c=5,d=a*b*c;

console.log("multiply of a,b and c is: ",d);
