let salary_per_hour=25;

let monthly_salary=25*160;

console.log("monthly salary is: ",monthly_salary);
