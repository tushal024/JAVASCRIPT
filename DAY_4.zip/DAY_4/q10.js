let a=15,b=8,c=a-b;

console.log("difference is : ",c);