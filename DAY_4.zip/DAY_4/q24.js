let amount=150,tex=15,se=10;
let total = (amount*tex)/100+amount;
console.log ("total amount is: ",total+se);
