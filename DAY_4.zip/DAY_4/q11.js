let item=3, price=15;

console.log("total items price is: ",item*price);