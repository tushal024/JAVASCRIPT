// Calculate the annual salary of an employee paid $40 per hour for 2400 hours .

let hourly_wage = 40, hours = 2400, annual_salary;

annual_salary = hourly_wage * hours;

console.log("annual salary is : ",annual_salary);