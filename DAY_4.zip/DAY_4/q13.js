var value= 2000, rate=3, time=4;


var s_i= (value*rate*time)/100;

console.log("Simple Interest is: ",s_i);