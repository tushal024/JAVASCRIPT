let x=2,y=8;

console.log("sum of x and y: ",x+y)
