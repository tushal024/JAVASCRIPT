var value= 1000, rate=5, time=2;


var s_i= (value*rate*time)/100;

console.log("Simple Interest is: ",s_i);