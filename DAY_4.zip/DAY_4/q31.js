// Question: Find the simple interest for $5000 at 3.5% interest rate for 10 years.

let p=5000,i=3.5,t=10;

let ii=(p*i*t)/100;

console.log(ii);
