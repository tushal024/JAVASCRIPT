let amount=50;
let inte=8;

let total_amount=amount*(inte/100)+amount;

console.log("Total amount is: ",total_amount)