
let amount = 4500 , i = 6 , Time = 7 , si;

 si = (amount * i * Time) /100;

 console.log("Simple interest: ",si);