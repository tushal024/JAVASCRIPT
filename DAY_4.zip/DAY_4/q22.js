let amount=100,tex=10,tip=20;

let total = amount+(amount*tex)/100;//110
let c = total+(total*tip)/100;

console.log("fainal is: ",c);



