let salary_per_hour=18;

let monthly_salary=18*180;

console.log("monthly salary is: ",monthly_salary);
