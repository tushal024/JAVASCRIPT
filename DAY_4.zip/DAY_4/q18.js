let amount = 90,
  inte = 7,
  total_value = amount + (amount * inte) / 100;

console.log("total amount is: ", total_value);
